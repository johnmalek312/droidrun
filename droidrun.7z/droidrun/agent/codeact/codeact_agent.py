import base64
import logging
import re
import inspect
import time # For timestamps in steps
from enum import Enum
from typing import Awaitable, Callable, List, Optional, Dict, Any, Tuple, TYPE_CHECKING

# LlamaIndex imports for LLM interaction and types
from llama_index.core.base.llms.types import ChatMessage, ChatResponse, ImageBlock, TextBlock
from llama_index.core.prompts import PromptTemplate
from llama_index.core.llms.llm import LLM
from llama_index.core import set_global_handler
set_global_handler("arize_phoenix")
# Load environment variables (for API key)
from dotenv import load_dotenv
load_dotenv()

if TYPE_CHECKING:
    import sys
    sys.path.append("../..")  # Adjust path for local imports
    from tools import Tools

logger = logging.getLogger("droidrun")
logging.basicConfig(level=logging.INFO)

# Simple token estimator (very rough approximation)
def estimate_tokens(text: str) -> int:
    """Estimate number of tokens in a string.
    
    This is a very rough approximation based on the rule of thumb that
    1 token is approximately 4 characters for English text.
    
    Args:
        text: Input text
    
    Returns:
        Estimated token count
    """
    if not text:
        return 0
    return len(text) // 4 + 1  # Add 1 to be safe

# --- Agent Definition ---

DEFAULT_CODE_ACT_PROMPT = """You are a helpful AI assistant that can write and execute Python code to solve problems.

You will be given a task to perform. You should output:
- Python code wrapped in ``` tags that provides the solution to the task, or a step towards the solution. Any output you want to extract from the code should be printed to the console.
- Text to be shown directly to the user, if you want to ask for more information or provide the final answer.
- If the previous code execution can be used to respond to the user, then respond directly (typically you want to avoid mentioning anything related to the code execution in your response).
-

## Response Format:
Example of proper code format:
To calculate the area of a circle, I need to use the formula: area = pi * radius^2. I will write a function to do this.
```python
import math

def calculate_area(radius):
    return math.pi * radius**2

# Calculate the area for radius = 5
area = calculate_area(5)
print(f"The area of the circle is {area:.2f} square units")
```

In addition to the Python Standard Library and any functions you have already written, you can use the following functions:
{tool_descriptions}

All code executions from previous steps are not available in the current step. You can only use the code you write in this step.

## Final Answer Guidelines:
- When providing a final answer, focus on directly answering the user's question
- Avoid referencing the code you generated unless specifically asked
- Present the results clearly and concisely as if you computed them directly
- If relevant, you can briefly mention general methods used, but don't include code snippets in the final answer
- Structure your response like you're directly answering the user's query, not explaining how you solved it

Reminder: Always place your Python code between ```...``` tags when you want to run code. 

You MUST ALWAYS to include your reasoning and thought process outside of the code block.
"""

class CodeActStepType(Enum):
    """Types of steps in the CodeAct agent's process."""
    GOAL = "goal"              # The initial user request
    THOUGHT = "thought"        # LLM reasoning text (outside code blocks)
    OBSERVATION = "observation"  # Result of code execution
    STATE = "state"            # Placeholder for future state information (e.g., UI elements) - Not used yet

class CodeActStep:
    """A single step in the CodeAct agent's process."""

    def __init__(
        self,
        step_type: CodeActStepType,
        content: str,
    ):
        """Initialize a CodeAct step."""
        self.step_type = step_type
        self.content = content
        self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """Convert the step to a dictionary."""
        return {
            "type": self.step_type.value,
            "content": self.content,
            "timestamp": self.timestamp
        }

    def __str__(self) -> str:
        """String representation of the step."""
        type_str = self.step_type.value.upper()
        if self.step_type == CodeActStepType.GOAL:
            return f"🎯 GOAL: {self.content}"
        elif self.step_type == CodeActStepType.THOUGHT:
            return f"🤔 THOUGHT:\n{self.content.strip()}"
        elif self.step_type == CodeActStepType.OBSERVATION:
            return f"👁️ OBSERVATION:\n{self.content.strip()}"
        elif self.step_type == CodeActStepType.STATE:
            return f"ℹ️ STATE:\n{self.content.strip()}" # Future use
        return f"{type_str}: {self.content}"

# --- Updated System Prompt ---
# Guides the LLM towards a Thought -> Code -> Observation cycle
class CodeActAgent:
    """
    An agent that uses a ReAct-like cycle (Thought -> Code -> Observation)
    to solve problems requiring code execution. It extracts code from
    Markdown blocks and uses specific step types for tracking.
    """
    def __init__(
        self,
        goal: str,
        llm: LLM,
        code_execute_fn: Callable[[str], Awaitable[Dict[str, Any]]],
        tools: 'Tools',
        available_tools: List = [],
        max_steps: int = 10, # Default max steps
        system_prompt: Optional[str] = None,
    ):
        # assert instead of if
        assert llm, "llm must be provided."
        assert code_execute_fn, "code_execute_fn must be provided"

        self.llm = llm
        self.code_execute_fn = code_execute_fn
        self.system_prompt_template = PromptTemplate(system_prompt or DEFAULT_CODE_ACT_PROMPT)
        self.available_tools = available_tools or []
        self.tools = tools
        self.max_steps = max_steps
        self.goal = goal
        self.steps: List[CodeActStep] = []
        self.tool_descriptions = self.parse_tool_descriptions() # Parse tool descriptions once at initialization


    def parse_tool_descriptions(self) -> str:
        """Parses the available tools and their descriptions for the system prompt."""
        # self.available_tools is a list of functions, we need to get their docstrings, names, and signatures and display them as `def name(args) -> return_type:\n"""docstring"""    ...\n`
        tool_descriptions = []
        for tool in self.available_tools:
            assert callable(tool), f"Tool {tool} is not callable."
            tool_name = tool.__name__
            tool_signature = inspect.signature(tool)
            tool_docstring = tool.__doc__ or "No description available."
            # Format the function signature and docstring
            formatted_signature = f"def {tool_name}{tool_signature}:\n    \"\"\"{tool_docstring}\"\"\"\n..."
            tool_descriptions.append(formatted_signature)
        # Join all tool descriptions into a single string
        return "\n".join(tool_descriptions)


    async def add_step(
        self,
        step_type: CodeActStepType,
        content: str,
    ) -> CodeActStep:
        """Adds a step to the agent's history and logs it."""
        step = CodeActStep(step_type, content)
        self.steps.append(step)
        logger.info(f"\n{step}") # Log the step as it's added
        return step

    def _extract_code_and_thought(self, response_text: str) -> Tuple[Optional[str], str]:
        """
        Extracts code from Markdown blocks (```python ... ```) and the surrounding text (thought).

        Returns:
            Tuple[Optional[code_string], thought_string]
        """
        code_pattern = r"```python\s*\n(.*?)\n```"
        code_matches = list(re.finditer(code_pattern, response_text, re.DOTALL))

        if not code_matches:
            # No code found, the entire response is thought
            return None, response_text.strip()

        # Combine all extracted code blocks
        extracted_code = "\n\n".join([match.group(1).strip() for match in code_matches])

        # Extract thought text (text before the first code block and after the last)
        thought_parts = []
        last_end = 0
        for match in code_matches:
            start, end = match.span()
            thought_parts.append(response_text[last_end:start])
            last_end = end
        thought_parts.append(response_text[last_end:]) # Text after the last block

        thought_text = "".join(thought_parts).strip()

        return extracted_code, thought_text

    def _create_system_prompt(self) -> str:
        """Creates the system prompt string, including tool descriptions."""
        return self.system_prompt_template.format(tool_descriptions=self.tool_descriptions)

    def _create_user_prompt(
        self,
        goal: str,
        history: List[Dict[str, Any]],
    ) -> str:
        """Create the user prompt for the LLM.
        
        Args:
            goal: The automation goal
            history: List of previous steps
        
        Returns:
            User prompt string
        """
        prompt = f"Goal: {goal}\n\n"
        
        # Add truncated history if available
        if history:
            # Start with a budget for tokens (very rough approximation)
            total_budget = 100000  # Conservative limit to leave room for response
            
            # Estimate tokens for the goal and other parts
            goal_tokens = estimate_tokens(goal) * 2  # Account for repetition
            
            # Calculate remaining budget for history
            history_budget = total_budget - goal_tokens
            
            # Start with most recent history and work backwards
            truncated_history = []
            current_size = 0
            
            # Copy and reverse history to process most recent first
            reversed_history = list(reversed(history))
            
            for step in reversed_history:
                step_type = step.get("type", "").upper()
                content = step.get("content", "")
                step_text = f"{step_type}: {content}\n"
                step_tokens = estimate_tokens(step_text)
                
                # If this step would exceed our budget, stop adding
                if current_size + step_tokens > history_budget:
                    # Add a note about truncation
                    truncated_history.insert(0, "... (earlier history truncated)")
                    break
                
                # Otherwise, add this step and update our current size
                truncated_history.insert(0, step_text)
                current_size += step_tokens
            
            # Add the truncated history to the prompt
            prompt += "History:\n"
            for step_text in truncated_history:
                prompt += step_text
            prompt += "\n"
        
        prompt += "Based on the current state, What are you doing next? Your response MUST include the thought process outside code block."
        
        # Final sanity check - if prompt is still too large, truncate aggressively
        if estimate_tokens(prompt) > 100000:
            logger.warning("Prompt still too large after normal truncation. Applying emergency truncation.")
            # Keep the beginning (goal) and end (instructions) but truncate the middle
            beginning = prompt[:2000]  # Keep goal
            end = prompt[-1000:]       # Keep final instructions
            prompt = beginning + "\n... (content truncated to fit token limits) ...\n" + end
        
        return prompt
    def _prepare_llm_input(self) -> List[ChatMessage]:
        """Prepares the full list of ChatMessages for the LLM call."""
        messages = []
        system_message = ChatMessage(role="system", content=self._create_system_prompt())
        messages.append(system_message)
        user_blocks = []
        if self.tools.last_screenshot:
            # Add screenshot as an image block
            user_blocks.append(TextBlock(text="Screenshot of the device:"))
            base64_bytes = base64.b64encode(self.tools.last_screenshot)
            user_blocks.append(ImageBlock(image=base64_bytes))
        user_prompt_string = self._create_user_prompt(goal=self.goal, history=[step.to_dict() for step in self.steps])
        user_blocks.append(TextBlock(text=user_prompt_string))
        user_message = ChatMessage(role="user", blocks=user_blocks)
        messages.append(user_message)
        # The LLM sees the system prompt, then a single user message containing the goal and history.
        return messages

    async def run_step(self) -> bool:
        """
        Runs a single step of the agent's logic:
        1. Prepare history for LLM.
        2. Call LLM.
        3. Parse response into THOUGHT and potentially CODE.
        4. Add THOUGHT step.
        5. If CODE exists, execute it and add OBSERVATION step.
        Returns:
            bool: True if code was generated and executed in this step, False otherwise.
                Indicates whether the loop should likely continue.
        """
        # 1. Prepare LLM input from history
        llm_input_messages = self._prepare_llm_input()

        # 2. Call LLM
        try:
            # Note: We are sending the history as one user message.
            # The LLM's response will be a single assistant message.
            llm_response: ChatResponse = await self.llm.achat(llm_input_messages)
            full_response_text = llm_response.message.content or ""
            if not full_response_text:
                logger.warning("LLM returned empty response.")
                return False # Cannot proceed
        except Exception as e:
            logger.error(f"LLM Error: {e}")
            await self.add_step(CodeActStepType.OBSERVATION, f"LLM Error: {e}")
            return False # Stop on LLM error

        # 3. Parse response
        code_to_execute, thought_text = self._extract_code_and_thought(full_response_text)

        # 4. Add THOUGHT step
        if thought_text:
            await self.add_step(CodeActStepType.THOUGHT, thought_text)
        else:
            await self.add_step(CodeActStepType.THOUGHT, "(No reasoning text provided)")


        # 5. Execute Code and Add OBSERVATION step (if code exists)
        if code_to_execute:
            try:
                output_str = await self.code_execute_fn(code_to_execute)
                observation_content = f"Code execution:\n```\n{output_str}\n```"
            except Exception as e:
                observation_content = f"Execution failed:\n```\n{str(e)}\n```"

            await self.add_step(CodeActStepType.OBSERVATION, observation_content)
            return True # Code was executed, likely need another step
        else:
            # No code was generated, assume this is the final answer / end of process
            return False # No code executed, loop should likely stop

    async def run(self) -> List[CodeActStep]:
        """
        Runs the agent's Thought -> Code -> Observation loop to achieve the goal.
        """
        self.steps = [] # Clear history for a new run
        await self.add_step(CodeActStepType.GOAL, self.goal)

        for i in range(self.max_steps):
            logger.info(f"\n--- Starting Agent Step {i + 1}/{self.max_steps} ---")
            try:
                should_continue = await self.run_step()
                if not should_continue:
                    logger.info(f"\n--- Agent finished in {i + 1} steps (no code generated in last step). ---")
                    break # Stop if the last step didn't involve code execution
            except Exception as e:
                logger.error(f"\n!! Error during agent step {i + 1}: {e}")
                await self.add_step(CodeActStepType.OBSERVATION, f"Agent loop error: {e}")
                break # Stop the loop on unexpected error

            if i == self.max_steps - 1:
                logger.info(f"\n--- Max steps ({self.max_steps}) reached. ---")
                await self.add_step(CodeActStepType.OBSERVATION, "Max steps reached.")

        return self.steps
