from tools import Tools

# set environment variables for `DROIDRUN_DEVICE_SERIAL` to R5CY10VM7YT
import asyncio
import os
import json
# copy to clipboard package
import pyperclip
async def main():
    tool = Tools("192.168.0.2:5555")
    packages = await tool.list_packages()
    # convert to json string and copy to clipboard
    json_string = json.dumps(packages, indent=4)
    pyperclip.copy(json_string)
    print("Copied to clipboard:")

asyncio.run(main())